//
//  ItemCell+CoreDataClass.swift
//  ToDoList App
//
//  Created by Carolyn Yen on 3/20/17.
//  Copyright © 2017 frandz. All rights reserved.
//

import Foundation
import CoreData

@objc(ItemCell)
public class ItemCell: NSManagedObject {

}
