//
//  ItemCell+CoreDataClass.swift
//  MyDogs
//
//  Created by Carolyn Yen on 3/21/17.
//  Copyright © 2017 frandz. All rights reserved.
//

import Foundation
import CoreData

@objc(ItemCell)
public class ItemCell: NSManagedObject {

}
