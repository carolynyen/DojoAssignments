//
//  CustomCell.swift
//  MyDogs
//
//  Created by Carolyn Yen on 3/21/17.
//  Copyright © 2017 frandz. All rights reserved.
//

import Foundation
import UIKit

class CustomCell: UICollectionViewCell {
    @IBOutlet weak var background: UIImageView!
    
    @IBOutlet weak var namebuttonlabel: UIButton!
    
}

