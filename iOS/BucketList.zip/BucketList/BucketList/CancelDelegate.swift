//
//  CancelDelegate.swift
//  BucketList
//
//  Created by Carolyn Yen on 3/15/17.
//  Copyright © 2017 frandz. All rights reserved.
//

import Foundation
import UIKit
protocol CancelDelegate: class {
    func cancelpressed(by controller: UIViewController)
}
